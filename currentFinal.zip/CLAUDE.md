# CLAUDE.md — Ayo Konsultasi (Imanuel's Branch)

> This is the primary instruction file for the Claude Code agent.
> Read this file FIRST before touching any code.
> ⚠️ This file must NOT be pushed to the repo. Add it to .gitignore.

---

## Project Identity

**Ayo Konsultasi** — An academic consultation MVP built for a Software Engineering course (Roger Pressman).
Connects students with FILKOM UNKLAB lecturers for booking and conducting academic consultations.

- **Repo:** https://github.com/Imanuelpalenewen/Ayo-Konsultasi
- **Active branch:** `cleanup/david-features` (cleanup phase), then new branches per feature
- **Developer:** Imanuel Palenewen (solo — doing everything independently)
- **Context:** The current codebase is the result of a local merge from a teammate (David). It needs to be cleaned up and fixed before new features are added.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React + TypeScript + Vite |
| Styling | Tailwind CSS + shadcn/ui |
| Backend | Convex (serverless + realtime) |
| Database | Convex built-in DB |
| Auth | Convex Auth (password provider) |
| AI Primary | Google Gemini API (`@google/generative-ai`) |
| AI Fallback | Mistral API (via REST, fallback when Gemini hits rate limits) |
| Routing | React Router v6 |

---

## Environment Variables

Already configured — do NOT regenerate or hardcode:

```
CONVEX_DEPLOYMENT=...
VITE_CONVEX_URL=...
GEMINI_API_KEY=...        # server-side (Convex actions)
VITE_GEMINI_API_KEY=...   # dev/testing (frontend)
```

Variables to be added — instruct the user to set these in the Convex Dashboard:

```
MISTRAL_API_KEY=...            # get from console.mistral.ai — free tier
AI_PROVIDER=gemini             # "gemini" | "mistral" — swap without changing code
GEMINI_MODEL=gemini-2.0-flash  # default; swap to gemini-2.5-flash for demo/presentation
```

---

## Design References

| Source | URL | Notes |
|---|---|---|
| Figma | https://kite-schema-07049094.figma.site/ | Primary source of truth for all pages |
| Lovable | https://ayo-consult.lovable.app/ | Reference only for notification bell (yellow dot style) |

### Design Rules

- Figma is the primary reference for layout, color system, and components
- Notification bell: yellow dot indicator for unread notifications (Lovable style)
- Do NOT implement: Delete account option
- Date picker: use shadcn `<Calendar>` inside a `<Popover>` — never a plain text input
- Time picker: allow free-form input (user sets any hour:minute) — no preset slots
- **UI Language:** Mixed Indonesian/English — use English for short action labels (Accept, Decline, Reassign, Pending, Completed, Cancel, Submit, Save), use Bahasa Indonesia for long sentences, AI responses, notifications, error messages, and welcome text

### Responsive Design (mandatory on every page)

**Auth pages:**
- Desktop (md+): split screen — left 50% brand panel + right 50% form panel
- Left panel: `flex items-center justify-center`, inner content `max-w-sm`, vertically centered
- Mobile (<md): hide left panel (`hidden md:flex`), full-screen single-column form, zero scrolling, `h-screen flex flex-col justify-center`
- Mobile background: use brand gradient (yellow) as background — not plain white

**All other pages:**
- Sidebar → bottom tab bar or hamburger drawer on mobile
- Grid: `grid-cols-1` mobile → `grid-cols-2` tablet → `grid-cols-3` desktop
- No horizontal overflow on any viewport

---

## Agent Workflow — MUST BE FOLLOWED

### Core Principles

1. **One task = one commit** — never bundle multiple changes together
2. **Always wait for approval** after completing a task before moving to the next one
3. **Suggest the commit message** — the user executes the actual `git commit`
4. **Suggest the branch name** for new features — the user creates the branch
5. **Never push** anything. Pushing is the user's responsibility.
6. **Never break working code** — verify correctness before proceeding
7. **This file and all instruction .md files** must never be committed or pushed to the repo

### Task Completion Format

After every completed task, always output this exact format:

```
✅ DONE: [task name]

Changes made:
- [file changed — what was changed and why]

Please test:
- [exact steps the user should take to verify the change works]

If everything looks good, suggested commit message:
`[type]: [short description]`

Ready to proceed to: [next task name]?
```

### PR Description Format (when user is ready to merge)

```
## Summary
[What this branch accomplishes overall]

## Changes
- [list of changes]

## How to Test
- [step-by-step testing instructions]

## Traceability
- User Story: [US-XX]
- Pressman Principle: [principle name]
```

---

## AI Provider Architecture

### Principle: API-Agnostic Layer

All AI calls must go through the `callAI()` helper in `convex/aiProvider.ts`. Never call Gemini or Mistral directly from feature actions.

```typescript
// convex/aiProvider.ts
export async function callAI(prompt: string): Promise<string>
```

Behavior:
- Reads the `AI_PROVIDER` env var → selects the provider
- If `"gemini"`: use `GoogleGenerativeAI`, model from `GEMINI_MODEL` env var (default: `gemini-2.0-flash`)
- If `"mistral"`: call Mistral REST API at `https://api.mistral.ai/v1/chat/completions`, model `mistral-small-latest`
- If Gemini fails with a rate limit error → auto-fallback to Mistral (only if `MISTRAL_API_KEY` is available)
- Always returns a string; handle all errors with a graceful Bahasa Indonesia fallback message

### Usage Per Feature

| Feature | Provider |
|---|---|
| AI Chat (`/chat`) | Gemini primary, Mistral fallback |
| Lecturer Recommendation (booking flow) | Gemini primary, Mistral fallback |
| Reassign Recommendation (lecturer dashboard) | Gemini primary, Mistral fallback |

---

## Schema Changes Required

### `consultations` table — new fields to add

```typescript
locationType: v.union(v.literal("online"), v.literal("tatap_muka")),
locationDetail: v.optional(v.string()), // e.g. "Lobby GK1" or chosen platform name
meetLink: v.optional(v.string()),        // auto-generated on lecturer accept (online only)
reassignedFrom: v.optional(v.id("users")),  // original lecturer ID
reassignedTo: v.optional(v.id("users")),    // new lecturer ID
reassignReason: v.optional(v.string()),
```

### `userProfiles` table — avatar field semantics change

```typescript
// avatarUrl already exists as v.optional(v.string())
// New semantics: stores a Convex storageId instead of a raw URL
// In frontend: use useStorageUrl(avatarUrl) from convex/react to resolve the displayable URL
```

---

## Task List — Branch `cleanup/david-features`

Work through these in order. Wait for user approval before proceeding to the next task.

---

### TASK 1: Remove unnecessary files and folders

**Delete from the working directory (do not commit any of these):**
- `.agents/` — Convex agent skill artifacts, not part of the app
- `.claude/` — same as above
- `PROMPT.md` — old instruction file
- `docs/git-workflow.md` — superseded by this workflow
- `skills-lock.json` — agent artifact

**Make sure `.gitignore` includes:**
```
.agents/
.claude/
CLAUDE.md
PROMPT.md
skills-lock.json
```

**Suggested commit message:** `chore: remove agent artifacts and update gitignore`

---

### TASK 2: Fix student booking flow — add location type selection

**Files to change:**
- `convex/schema.ts` — add `locationType`, `locationDetail`, `meetLink` to the consultations table
- `convex/consultations.ts` — update `createConsultation` mutation args to include the new fields
- `src/pages/consultation/BookingPage.tsx` — add location selection UI

**UI details for BookingPage:**
After the "Topic" field, add a "Jenis Pertemuan" (Meeting Type) section with two radio card options:
- 🌐 **Online** — sub-options: Google Meet / Zoom (radio). Show a small note below: `"Link meeting akan digenerate otomatis setelah dosen menyetujui."`
- 🏢 **Tatap Muka** (In-person) — free-text input for location. Placeholder: `"Contoh: Lobby GK1, Ruang Dosen Lt. 3, Kafe Manado"`

**Suggested commit message:** `feat(booking): add location type selection (online/tatap-muka)`

---

### TASK 3: Fix student flow — AI recommendation belongs inside booking, not a separate tab

**Problem:** The Sidebar has "Rekomendasi AI" as a standalone nav link. The correct UX is: AI recommendation is a step *within* the booking flow, not a separate destination.

**Changes:**
- `src/components/shared/Sidebar.tsx` — remove the "Rekomendasi AI" nav link from student menu; keep "Booking Konsultasi"
- `src/pages/consultation/BookingPage.tsx` — merge the FindLecturer flow into this page:
  - **Step 1:** User fills topic, description, preferred dates, and meeting type
  - **Step 2 (same page):** "Cari Dosen dengan AI" button → calls `recommendLecturers` → shows results below with a loading animation
  - **Step 3:** User picks a lecturer from the recommendations → full booking form appears (specific date, time, notes) → Submit
- `src/App.tsx` — remove or redirect `/student/find-lecturer` to `/student/book`
- **Loading animation:** Show an overlay with rotating messages cycling every 3 seconds:
  - "Menganalisis keahlian dosen..."
  - "Mencocokkan jadwal tersedia..."
  - "Menyiapkan rekomendasi terbaik untukmu..."
  - Add an estimated wait indicator: `"Biasanya membutuhkan 5–10 detik"`

**Suggested commit message:** `refactor(student): integrate AI recommendation into booking flow`

---

### TASK 4: Fix change password bug

**Problem:** The current implementation updates `userProfiles` but Convex Auth stores the password hash in its own internal `authAccounts` table. Password changes must go through the Convex Auth API.

**Files to change:**
- `convex/users.ts` — replace the existing `changePassword` mutation to use `updateAccountPasswordAndSignIn` from `@convex-dev/auth/server`
- `src/components/profile/ChangePasswordForm.tsx` — confirm the form sends both `currentPassword` and `newPassword`

**Implementation reference:**
```typescript
import { updateAccountPasswordAndSignIn } from "@convex-dev/auth/server";

// Inside mutation handler:
await updateAccountPasswordAndSignIn(ctx, {
  currentPassword: args.currentPassword,
  newPassword: args.newPassword,
});
```

**Suggested commit message:** `fix(auth): sync password change with Convex Auth provider`

---

### TASK 5: Refactor profile page — replace vertical scroll with tabs

**Problem:** AvailabilityForm is below the ProfilePage, requiring excessive scrolling. For lecturers it is especially hard to find.

**Changes:**
- `src/pages/profile/ProfilePage.tsx` — add a tab row at the top of the forms area:
  - Tab 1: **"Info Pribadi"** — `ProfileForm`
  - Tab 2: **"Keamanan"** — `ChangePasswordForm` (with eye icon toggles on all password fields — see Task 6)
  - Tab 3: **"Jadwal Tersedia"** — only rendered when `user.role === "lecturer"`, contains `AvailabilityForm`
- Use existing shadcn/ui: `<Tabs>`, `<TabsList>`, `<TabsTrigger>`, `<TabsContent>`

**Suggested commit message:** `refactor(profile): reorganize profile page with tab navigation`

---

### TASK 6: Add password visibility toggle to all password fields

**Files to change:**
- `src/pages/auth/Login.tsx` — add eye toggle on the password field
- `src/pages/auth/Register.tsx` — add eye toggle on all password fields
- `src/components/profile/ChangePasswordForm.tsx` — add eye toggle on all password fields
- Use `Eye` and `EyeOff` icons from `lucide-react`
- Toggle button must meet the 44×44px minimum touch target size

**Suggested commit message:** `feat(ux): add password visibility toggle to all password fields`

---

### TASK 7: Avatar upload via file (replace URL input)

**Files to change:**
- `convex/users.ts` — add two new mutations:
  - `generateUploadUrl` — returns a Convex storage pre-signed upload URL
  - `updateAvatar` — saves the returned `storageId` to `userProfiles.avatarUrl`
- `src/pages/profile/ProfilePage.tsx` — overlay a camera/edit icon button on the avatar circle. Clicking it triggers a hidden file input → uploads the file → avatar updates immediately via reactive query
- Use `useStorageUrl(storageId)` from `convex/react` to render the avatar
- Accepted file types: JPG, PNG, WEBP — max 5MB
- Show a small loading spinner on the avatar while uploading

**Suggested commit message:** `feat(profile): enable avatar upload via file using Convex storage`

---

### TASK 8: Add AM/PM tooltip badge component

**Files to change:**
- Create `src/components/shared/AMPMBadge.tsx` — a small reusable badge that shows "AM" or "PM" and reveals a tooltip on hover:
  - "AM" → `"AM (Ante Meridiem): pukul 00:00 – 11:59"`
  - "PM" → `"PM (Post Meridiem): pukul 12:00 – 23:59"`
- Use this component wherever AM/PM appears in the UI: `AvailabilityForm`, `BookingPage`, `WeeklySchedule`
- Implement tooltip with shadcn/ui `<TooltipProvider>` + `<Tooltip>` + `<TooltipContent>`

**Suggested commit message:** `feat(ux): add reusable AM/PM tooltip badge component`

---

### TASK 9: Add Reassign feature for lecturers with AI recommendation

**This is the most complex task — complete it last in this branch.**

**Schema:** Add the fields listed in the Schema Changes section above.

**Backend — `convex/consultations.ts`:**
- Add mutation `reassignConsultation(consultationId, newLecturerId, reason?)`:
  - Keep status as `"pending"` but populate `reassignedFrom`, `reassignedTo`, `reassignReason`
  - Send notifications to: the student (their consultation was reassigned to a different lecturer) and the new lecturer (new request incoming)

**Backend — `convex/ai.ts`:**
- Add action `recommendReassignTargets(consultationId)`:
  - Fetch the consultation details (topic, notes, scheduled date/time)
  - Fetch all lecturers except the one who is currently reassigning
  - Filter for lecturers with availability that overlaps or is adjacent to the consultation's scheduled time
  - Call `callAI()` with a prompt to rank the top 3 best-fit lecturers for this reassignment, with a short reasoning for each
  - Return the same JSON shape as `recommendLecturers`

**Frontend:**
- `src/components/dashboard/IncomingRequests.tsx` — add a "Reassign" button alongside the existing Accept and Decline buttons
- Clicking "Reassign" opens a modal/sheet with:
  - Top section: AI loading animation while fetching recommendations
  - Results: 3 AI-recommended lecturer cards (name, reason, matching schedule slot)
  - Below results: a "Atau pilih dosen lain" dropdown (full list of other lecturers)
  - Optional text field: "Alasan Reassign" (reason — for audit trail)
  - Action buttons: "Reassign" (primary) + "Batal" (cancel)

**Suggested commit message:** `feat(lecturer): add AI-powered reassign consultation feature`

---

### TASK 10: Replace seed data with official UNKLAB data

**Overwrite `convex/seed.ts` entirely using the cleaned data below.**

**Important notes before writing the seed:**
- Call `clearLecturers` first to remove all old lecturer data before running the new seed
- Skip "Jordy Gapian" — no email address in the source data
- Andria K. Wahyudi is a **lecturer** — the source data incorrectly sets the role to `student`; correct it to `lecturer`
- All emails must be lowercase with no spaces
- After updating seed data, sync the lecturer list in the system prompt inside `convex/chat.ts` to match the new data

**Lecturer data (cleaned from Datadummy.xlsx):**

| Name | Email | NIP | Expertise | Availability |
|---|---|---|---|---|
| Stenly R. Pungus, S.Kom., MT., M.M., Ph.D | stenly.pungus@dosen.unklab.ac.id | 198501012010011000 | Dean, Software Engineering, Thesis Supervision, Research Methodology | Monday 09:00–12:00 |
| Semmy W. Taju, S.Kom., M.S., Ph.D | semmy.taju@dosen.unklab.ac.id | 197912152008011002 | Head of Informatics, AI, Machine Learning, Thesis Supervision | Monday 13:00–15:00 |
| Jimmy H. Moedjahedy, S.Kom., M.M., M.Kom | jimmy.moedjahedy@dosen.unklab.ac.id | 198307212011012003 | Head of Information Systems, Web Development, Computer Networks, Thesis Supervision | Wednesday 09:00–12:00 |
| Ir. Marchel Timothy Tombeng, S.Kom., MS | marchel.tombeng@dosen.unklab.ac.id | 197805062007011004 | Head of Information Technology, Web Development, Thesis Supervision | Tuesday 13:00–16:00 |
| Prof. Andrew T. Liem, S.Si., MT., Ph.D | andrew.liem@dosen.unklab.ac.id | 198912112015012005 | Informatics, Computer Networks, Software Engineering, AI, Thesis Supervision | Wednesday 09:00–12:00 |
| Debby E. Sondakh, S.Kom., M.T., Ph.D | debby.sondakh@dosen.unklab.ac.id | 198104092009011006 | Informatics, Data Analytics, Research Methodology, Proposal Writing, Thesis Supervision | Wednesday 13:00–15:00 |
| Ir. Edson Y. Putra, M.Kom | edson.putra@dosen.unklab.ac.id | 198606172012012007 | Information Systems, Database Management, Thesis Supervision | Thursday 13:00–16:00 |
| Oktoverano H. Lengkong, S.Kom., M.Ds., M.M. | oktoverano.lengkong@dosen.unklab.ac.id | 197711252006011008 | Information Technology, Web Development, UI/UX Design, Graphic Design, Thesis Supervision | Friday 09:00–11:00 |
| Green Ferry Mandias, S.Kom., M.Cs., M.M | green.mandias@dosen.unklab.ac.id | 199001032016012009 | Informatics, Database Management, Thesis Supervision | Friday 13:00–15:00 |
| Green A. Sandag, S.Kom., M.S | green.sandag@dosen.unklab.ac.id | 198208142010011010 | Informatics, Artificial Intelligence, Natural Language Processing, Thesis Supervision | Friday 09:00–12:00 |
| Jacquline M. Waworundeng, S.T., M.T | jacquline.waworundeng@dosen.unklab.ac.id | 198711192013012011 | Informatics, Robotics, Internet of Things, Thesis Supervision | Tuesday 08:00–11:00 |
| Reynoldus A. Sahulata, S.Kom., M.M. | reynoldus.sahulata@dosen.unklab.ac.id | 198203152009011012 | Information Systems, Management Information Systems, IT Governance, Thesis Supervision | Friday 09:00–12:00 |
| Joe Y. Y. Mambu, B.IT., MCIS | joe.mambu@dosen.unklab.ac.id | 197909082007012013 | Information Systems, Enterprise Resource Planning (ERP), Thesis Supervision | Thursday 14:00–16:00 |
| Lidya C. Laoh, S.Kom, M.Msi | lidya.laoh@dosen.unklab.ac.id | 198611232012011014 | Information Systems, Data Structures, Thesis Supervision | Thursday 14:00–16:00 |
| Wilsen Grivin Mokodaser, S.Kom., M.Kom | wilsen.mokodaser@dosen.unklab.ac.id | 197512302005011015 | Informatics, Computer Networks, Thesis Supervision | Monday 10:00–12:00 |
| Reymon Rotikan, S.Kom., M.S., M.M. | reymon.rotikan@dosen.unklab.ac.id | 198907142014012016 | Information Systems, Database Management, Thesis Supervision | Friday 13:00–15:00 |
| Rolly J. Lontaan, S.Kom., M.Kom | rolly.lontaan@dosen.unklab.ac.id | 198001252008011017 | Informatics, System Programming, Thesis Supervision | Monday & Wednesday 10:00–12:00 |
| Stenly I. Adam, S.Kom., M.Sc | stenly.adam@dosen.unklab.ac.id | 197811092006012018 | Informatics, Mobile App Development, Thesis Supervision | Monday 09:00–12:00 |
| George M. W. Tangka, S.Kom., MBA | george.tangka@dosen.unklab.ac.id | 199102182017011019 | Information Systems, Business Intelligence, Data Analytics, Management Information Systems, Thesis Supervision | Thursday 13:00–16:00 |
| Andria K. Wahyudi, SKom, M.Eng | andria.wahyudi@dosen.unklab.ac.id | 198405062010012020 | Informatics, Thesis Supervision | Monday 13:00–15:00 |
| Raissa Camila Maringka, S.Kom., M.Kom | raissa.maringka@dosen.unklab.ac.id | 198712212013011021 | Informatics, Algorithms, Thesis Supervision | Wednesday 13:00–15:00 |
| Argha O. Silitonga, S.Kom., M.S | argha.silitonga@dosen.unklab.ac.id | 198305172009011023 | Informatics, Game Development, Thesis Supervision | Monday 13:00–15:00 |
| Regi F. Najoan, S.Kom., M.Kom | regi.najoan@dosen.unklab.ac.id | 197912082007012024 | Informatics, Web Development, Thesis Supervision | Wednesday 13:00–15:00 |
| Julio Kolapitawondal, S.Kom., M.I | julio.kolapitawondal@dosen.unklab.ac.id | 199104252018011025 | Information Technology, Graphic Design, Video Editing, Animation, UI/UX, Thesis Supervision | Thursday 08:00–11:00 |

**All lecturer passwords:** `dosen123`

**Student data (cleaned from Datadummy.xlsx):**

| Name | Email | NIM | Major | Password |
|---|---|---|---|---|
| Anisa Putri | s2222051001@student.unklab.ac.id | 22051001 | Informatics | student123 |
| Budi Pratama | s2222051002@student.unklab.ac.id | 22051002 | Informatics | student123 |
| Citra Lestari | s2222051003@student.unklab.ac.id | 22051003 | Informatics | student123 |
| Dimas Saputra | s2222051004@student.unklab.ac.id | 22051004 | Information Systems | student123 |
| Tinusmar Sheptia | s2222051005@student.unklab.ac.id | 22051005 | DKV | student123 |
| Nona Umboh | s2222051006@student.unklab.ac.id | 22051006 | Informatics | student123 |
| Valerie Liogu | s2222051007@student.unklab.ac.id | 22051007 | Informatics | student123 |
| Nobel Situmorang | s2222051008@student.unklab.ac.id | 22051008 | Informatics | student123 |
| Septian Rantung | s2122051009@student.unklab.ac.id | 22051009 | Information Systems | student123 |
| Intan Sari | s2222051010@student.unklab.ac.id | 22051010 | Information Systems | student123 |
| Budi Marloy | s2222051011@student.unklab.ac.id | 22051011 | Informatics | student123 |
| Kevin Sartono | s2222051012@student.unklab.ac.id | 22051012 | Information Systems | student123 |
| Novian Susanto | s2222051013@student.unklab.ac.id | 22051013 | DKV | student123 |
| Ivana Sondakh | s2222051014@student.unklab.ac.id | 22051014 | Information Systems | student123 |
| Caren Kaunang | s2222051015@student.unklab.ac.id | 22051015 | Information Systems | student123 |
| Lemmy Lengkong | s2222051016@student.unklab.ac.id | 22051016 | Informatics | student123 |
| Dodi Gerungan | s2222051017@student.unklab.ac.id | 22051018 | DKV | student123 |
| Marshel Lawitan | s2222051018@student.unklab.ac.id | 22051019 | DKV | student123 |
| Adam Maengkong | s2222051019@student.unklab.ac.id | 22051017 | Informatics | student123 |
| Stenly Pangelewen | s2222051020@student.unklab.ac.id | 22051020 | Information Systems | student123 |
| Iman Permata Kandow | s2222051021@student.unklab.ac.id | 22051022 | DKV | student123 |
| Jeremmiah Kuagow | s2122051022@student.unklab.ac.id | 22051023 | Informatics | student123 |
| Andrew Lenzun | s2222051023@student.unklab.ac.id | 22051024 | Information Systems | student123 |
| Marsel Wijaya | s2222051024@student.unklab.ac.id | 22051025 | Informatics | student123 |
| Wilson Alow | s2222051025@student.unklab.ac.id | 22051026 | Informatics | student123 |

**Suggested commit message:** `feat(seed): replace dummy data with official UNKLAB lecturer and student data`

---

## New Features — Separate Branches (After Cleanup is Merged)

Complete these ONLY after `cleanup/david-features` has been merged into `development`.

---

### Feature: OTP Password Reset & Forgot Password

**Branch:** `feature/otp-password-reset`

**Scope:**
1. Auth page: add a "Lupa Password?" link below the login form
2. Forgot password flow:
   - User enters email → system sends a 6-digit OTP via email using **Resend** (free tier: 3,000 emails/month)
   - User enters OTP → verified → new password form appears
   - Integrate with Convex Auth's `resetPassword` flow
3. Reset password from inside the dashboard (for logged-in users):
   - In the "Keamanan" tab of the profile page, add a "Reset via OTP" option as an alternative to the manual change-password form
   - OTP is sent to the user's registered email address

**Resend setup (instruct the user to do this manually):**
```
1. Sign up at resend.com (free)
2. Go to API Keys → Create API Key
3. Set in Convex Dashboard: RESEND_API_KEY=re_xxxx
4. For testing: use onboarding@resend.dev as sender (no domain verification required)
5. For production/demo: verify unklab.ac.id or another domain you control
```

**New schema table:**
```typescript
otpVerifications: defineTable({
  email: v.string(),
  otp: v.string(),       // 6-digit, stored hashed
  expiresAt: v.number(), // Date.now() + 10 minutes
  used: v.boolean(),
  createdAt: v.number(),
}).index("by_email", ["email"])
```

**Suggested commit messages (one per step):**
- `feat(auth): add forgot password page and OTP request flow`
- `feat(auth): integrate Resend email service for OTP delivery`
- `feat(auth): implement OTP verification and password reset`
- `feat(profile): add OTP-based password reset option in security tab`

**PR title:** `feat: OTP-based password reset (forgot password + in-profile reset)`

---

### Feature: Auth Page UI Overhaul + Animations

**Branch:** `feature/auth-ui-animation`

**Scope:**
1. Mobile auth page: replace plain white background with the brand yellow gradient — form stays centered
2. Animated AK logo on auth page: the logo glows on and off using a CSS keyframe gradient animation (`background-position` shifting)
3. Improved AK logo: build a polished SVG logo component with stylized A and K letterforms and a yellow brand gradient — replaces the current plain text "AK" badge
4. Additional auth animations: form card fades in on initial load; submit button has a subtle ripple effect on click
5. Left brand panel: add a floating illustration or decorative element with a smooth up-down float animation (custom CSS keyframe or `animate-bounce`)

**Suggested commit messages:**
- `feat(auth): redesign mobile auth layout with brand gradient background`
- `feat(auth): create animated AK SVG logo component`
- `feat(auth): add entrance animations to auth form and brand panel`

---

## Roger Pressman Principles — Mapping to This Project

1. **Incremental Process Model** → each task is a self-contained commit that can be independently demoed
2. **Requirements Traceability** → every PR must reference a User Story (US-XX) in its description
3. **Software Quality Attributes** → maintainability (strict TypeScript), reliability (all async ops have error handling), usability (loading states, animated feedback)
4. **Design Patterns** → Repository pattern via Convex queries/mutations; AI Provider abstraction layer (`callAI()`)
5. **Testing** → unit tests for critical Convex mutations: at minimum `createConsultation`, `reassignConsultation`, `changePassword`
6. **Documentation** → update `docs/implementation.md` after every completed feature

---

## General Technical Rules

- TypeScript strict mode — no `any` types unless truly unavoidable (add a comment explaining why if used)
- Every async operation must have proper error handling and user-facing feedback
- Convex best practices: use `query`, `mutation`, `action` correctly — business logic belongs in mutations, not React components
- Never commit `.env.local` or any file containing API keys
- Never install a new npm package without informing the user and getting explicit approval first
- Always prefer existing shadcn/ui components over building new custom ones from scratch
