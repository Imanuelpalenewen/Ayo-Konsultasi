# Cleanup Branch Plan — `cleanup/david-features`

> **Purpose:** This file is the authoritative progress tracker for the `cleanup/david-features` branch.
> Any agent or developer picking up this branch mid-way must read this first.
> Update the status column as each task completes.

---

## Branch Goal

Clean up the codebase after absorbing a local merge from teammate David. Fix half-finished
flows, unify the AI layer behind a provider abstraction, and align the codebase with the
correct UX spec before starting new feature branches.

**Base branch:** `development`
**Merge target:** `development`
**Started:** 2026-05-03

---

## Scope Boundaries

| In scope | Out of scope |
|---|---|
| All 10 tasks listed below | Auth visual overhaul (AK SVG logo, animations, mobile gradient) → `feature/auth-ui-animation` |
| `convex/aiProvider.ts` abstraction (folded into Task 3) | OTP password reset → `feature/otp-password-reset` |
| Official UNKLAB seed data | New features beyond the task list |

---

## Current State at Branch Start (verified 2026-05-03)

| Area | Finding | Task that fixes it |
|---|---|---|
| `.agents/`, `.claude/`, `PROMPT.md`, `docs/git-workflow.md`, `skills-lock.json` | All present on disk; `.gitignore` already excludes them | Task 1 |
| `convex/schema.ts` consultations table | Missing `locationType`, `locationDetail`, `meetLink`, `reassignedFrom`, `reassignedTo`, `reassignReason` | Task 2 |
| `convex/consultations.ts` `createConsultation` | Args don't include location fields | Task 2 |
| `src/pages/consultation/FindLecturer.tsx` | Standalone page at `/student/find-lecturer`; should be merged into BookingPage | Task 3 |
| `src/components/shared/Sidebar.tsx:25` | "Rekomendasi AI" link in student menu (separate nav, wrong UX) | Task 3 |
| `src/App.tsx:44-49` | `/student/find-lecturer` route wired separately | Task 3 |
| `convex/aiProvider.ts` | Does NOT exist; `ai.ts` and `chat.ts` call Gemini directly | Task 3 (creates it) |
| `convex/users.ts` | No `changePassword` mutation; `ChangePasswordForm.tsx` uses a 1s mock delay | Task 4 |
| `src/pages/profile/ProfilePage.tsx` | Vertical scroll layout with 3 stacked form sections | Task 5 |
| `src/components/profile/ChangePasswordForm.tsx` | No eye toggles (Login + Register already have them) | Task 6 |
| `convex/users.ts` | No avatar upload mutations; profile stores a plain URL string | Task 7 |
| AM/PM appears in `AvailabilityForm`, `BookingPage`, `WeeklySchedule` without explanation | No tooltip badge component | Task 8 |
| `src/components/dashboard/IncomingRequests.tsx` | Has Accept/Decline; no Reassign button | Task 9 |
| `convex/seed.ts` | 18 lecturers with wrong emails/NIP format; only 1 test student | Task 10 |
| `convex/chat.ts:136-209` | Hardcoded lecturer list in system prompt; will be stale after Task 10 | Task 10 |

---

## Task Status Tracker

Update `⬜ pending` → `✅ done @ <commit-message>` as each task is committed.

| # | Task | Status | Commit |
|---|---|---|---|
| 0 | Persist cleanup plan inside project (`docs/cleanup-plan.md`) | ✅ done | docs: add cleanup branch plan and progress tracker |
| 1 | Remove agent artifacts from disk | ✅ done | chore: remove agent artifacts |
| 2 | Add location type to schema + booking UI | ✅ done | feat(booking): add location type selection (online/tatap-muka) |
| 3 | Create `aiProvider.ts` + merge AI rec into booking + remove sidebar link | ✅ done | refactor(student): integrate AI recommendation into booking flow |
| 4 | Fix `changePassword` via Convex Auth | ✅ done | fix(auth): sync password change with Convex Auth provider |
| 5 | Profile page: replace vertical scroll with shadcn Tabs | ✅ done | refactor(profile): reorganize profile page with tab navigation |
| 6 | Eye toggle on `ChangePasswordForm` | ✅ done | feat(ux): add password visibility toggle to all password fields |
| 7 | Avatar file upload via Convex storage | ✅ done | feat(profile): enable avatar upload via file using Convex storage |
| 8 | Reusable `<AMPMBadge>` tooltip component | ✅ done | feat(ux): add reusable AM/PM tooltip badge component |
| 9 | Reassign consultation feature with AI recommendation modal | ⬜ pending | — |
| 10 | Replace seed with official UNKLAB data; sync `chat.ts` system prompt | ⬜ pending | — |

---

## Task Details

### Task 1 — Remove agent artifact files
**Files to delete:**
- `.agents/` (entire folder)
- `.claude/` (entire folder)
- `PROMPT.md`
- `docs/git-workflow.md`
- `skills-lock.json`

**Note:** `.gitignore` already lists all five — only disk deletion is needed, no gitignore edit.

**Suggested commit:** `chore: remove agent artifacts`

**If it breaks:** Nothing functional depends on these files. Safe to delete blindly.

---

### Task 2 — Add location type to booking
**Files:** `convex/schema.ts`, `convex/consultations.ts`, `src/pages/consultation/BookingPage.tsx`

**Schema additions** (all to the `consultations` table):
```typescript
locationType: v.union(v.literal("online"), v.literal("tatap_muka")),
locationDetail: v.optional(v.string()),
meetLink: v.optional(v.string()),
reassignedFrom: v.optional(v.id("users")),
reassignedTo: v.optional(v.id("users")),
reassignReason: v.optional(v.string()),
```
Note: `reassignedFrom/To/Reason` are added here too so Task 9 doesn't need another schema migration.

**UI spec** (after the Topic field in BookingPage):
- Section label: "Jenis Pertemuan"
- Radio card 1 — 🌐 **Online** → sub-radio: Google Meet | Zoom → note: "Link meeting akan digenerate otomatis setelah dosen menyetujui."
- Radio card 2 — 🏢 **Tatap Muka** → free-text input, placeholder: "Contoh: Lobby GK1, Ruang Dosen Lt. 3, Kafe Manado"

**Suggested commit:** `feat(booking): add location type selection (online/tatap-muka)`

**If it breaks:** If Convex schema migration fails, check that `locationType` is not marked `optional` — it is required but new bookings will start sending it. Existing test bookings in dev DB may fail until re-seeded (OK in dev).

---

### Task 3 — `aiProvider.ts` + merge AI rec into booking + remove sidebar link
**This task has three parts bundled in one commit.**

**Part A — Create `convex/aiProvider.ts`:**
```typescript
export async function callAI(prompt: string): Promise<string>
```
- Reads `AI_PROVIDER` env var (`"gemini"` | `"mistral"`)
- Gemini: use `GoogleGenerativeAI`, model from `GEMINI_MODEL` env var (default `gemini-2.0-flash`)
- Mistral: REST call to `https://api.mistral.ai/v1/chat/completions`, model `mistral-small-latest`
- Auto-fallback: if Gemini throws a rate-limit error AND `MISTRAL_API_KEY` is set → retry via Mistral
- Refactor `convex/ai.ts` and `convex/chat.ts` to call `callAI()` instead of calling `GoogleGenerativeAI` directly

**Part B — Merge FindLecturer into BookingPage (three-step flow):**
- Step 1: Topic, description, preferred dates, meeting type (from Task 2)
- Step 2: "Cari Dosen dengan AI" button → calls `api.ai.recommendLecturers` → loading overlay with rotating messages (3s cycle):
  - "Menganalisis keahlian dosen..."
  - "Mencocokkan jadwal tersedia..."
  - "Menyiapkan rekomendasi terbaik untukmu..."
  - Indicator: "Biasanya membutuhkan 5–10 detik"
- Step 3: Pick a lecturer from recommendation cards → booking form (specific date/time/notes) → Submit
- Delete `src/pages/consultation/FindLecturer.tsx`

**Part C — Remove sidebar link + route:**
- Remove "Rekomendasi AI" from student menu in `src/components/shared/Sidebar.tsx`
- Remove or redirect `/student/find-lecturer` to `/student/book` in `src/App.tsx`

**Suggested commit:** `refactor(student): integrate AI recommendation into booking flow`

**If it breaks:**
- If `callAI()` returns empty: check `AI_PROVIDER` is set in Convex Dashboard; if unset it defaults to Gemini
- If Gemini rate-limits: set `AI_PROVIDER=mistral` in Convex Dashboard (no code change needed) — but `MISTRAL_API_KEY` must also be set
- If the route redirect causes a blank page: verify `App.tsx` has a `<Navigate>` element pointing from `/student/find-lecturer` to `/student/book`

---

### Task 4 — Fix `changePassword`
**Files:** `convex/users.ts`, `src/components/profile/ChangePasswordForm.tsx`

```typescript
// convex/users.ts — add this mutation:
import { updateAccountPasswordAndSignIn } from "@convex-dev/auth/server";

export const changePassword = mutation({
  args: { currentPassword: v.string(), newPassword: v.string() },
  handler: async (ctx, args) => {
    await updateAccountPasswordAndSignIn(ctx, {
      currentPassword: args.currentPassword,
      newPassword: args.newPassword,
    });
  },
});
```

Remove the mock `setTimeout` in `ChangePasswordForm.tsx` and wire to the real mutation.

**Suggested commit:** `fix(auth): sync password change with Convex Auth provider`

**If it breaks:** `updateAccountPasswordAndSignIn` requires the current session to be active. If it throws "unauthorized", the user may be in a stale session — refreshing the page re-authenticates via Convex Auth's session cookie.

---

### Task 5 — Profile page tabs
**Files:** `src/pages/profile/ProfilePage.tsx`

Replace the three stacked sections with shadcn `<Tabs>`:
- Tab 1: **"Info Pribadi"** — `ProfileForm`
- Tab 2: **"Keamanan"** — `ChangePasswordForm`
- Tab 3: **"Jadwal Tersedia"** — `AvailabilityForm` (only rendered if `user.role === "lecturer"`)

Keep the avatar card on the left column (or above the tabs on mobile). Use existing shadcn components: `<Tabs>`, `<TabsList>`, `<TabsTrigger>`, `<TabsContent>`.

**Suggested commit:** `refactor(profile): reorganize profile page with tab navigation`

**If it breaks:** If `<Tabs>` isn't in `src/components/ui/`, run `npx shadcn@latest add tabs` — but check with Imanuel first before installing anything.

---

### Task 6 — Eye toggle on `ChangePasswordForm`
**File:** `src/components/profile/ChangePasswordForm.tsx`

Add `Eye`/`EyeOff` toggles from `lucide-react` to all three password fields (current, new, confirm). Each toggle button must be `min-w-[44px] min-h-[44px]` for mobile tap target.

**Note:** `Login.tsx` and `Register.tsx` already have this — only the profile form is missing.

**Suggested commit:** `feat(ux): add password visibility toggle to all password fields`

**If it breaks:** Nothing — purely additive UI change.

---

### Task 7 — Avatar file upload
**Files:** `convex/users.ts`, `src/pages/profile/ProfilePage.tsx`

New mutations in `convex/users.ts`:
- `generateUploadUrl` — returns Convex storage pre-signed URL
- `updateAvatar(storageId)` — saves `storageId` to `userProfiles.avatarUrl`

Frontend:
- Camera/edit icon overlay on the avatar circle
- Hidden `<input type="file" accept=".jpg,.jpeg,.png,.webp">` triggered on overlay click
- Max 5MB client-side check before upload
- Small spinner on the avatar while uploading
- Use `useStorageUrl(storageId)` from `convex/react` to resolve the displayable URL

**Suggested commit:** `feat(profile): enable avatar upload via file using Convex storage`

**If it breaks:** If `useStorageUrl` returns null immediately after upload, the Convex storage URL may take 1-2 seconds to resolve — add a loading fallback (show initials avatar while null).

---

### Task 8 — AM/PM tooltip badge
**New file:** `src/components/shared/AMPMBadge.tsx`

```typescript
// Props: { period: "AM" | "PM" }
// Tooltip content:
// AM → "AM (Ante Meridiem): pukul 00:00 – 11:59"
// PM → "PM (Post Meridiem): pukul 12:00 – 23:59"
```

Use shadcn `<TooltipProvider>` + `<Tooltip>` + `<TooltipContent>`.

Use this component wherever AM/PM appears: `AvailabilityForm`, `BookingPage`, `WeeklySchedule` (find exact path before editing).

**Suggested commit:** `feat(ux): add reusable AM/PM tooltip badge component`

**If it breaks:** If Tooltip isn't in `src/components/ui/`, check with Imanuel before running `npx shadcn@latest add tooltip`.

---

### Task 9 — Reassign consultation feature
**This is the most complex task. Do it last.**

Schema additions were already done in Task 2 (`reassignedFrom`, `reassignedTo`, `reassignReason`).

**Backend — `convex/consultations.ts`:**
```
reassignConsultation(consultationId, newLecturerId, reason?)
  - keeps status as "pending"
  - sets reassignedFrom, reassignedTo, reassignReason
  - sends notification to student (consultation reassigned)
  - sends notification to new lecturer (new request)
```

**Backend — `convex/ai.ts`:**
```
recommendReassignTargets(consultationId)
  - fetches consultation details (topic, notes, scheduled date/time)
  - fetches all lecturers except current one
  - filters for availability overlap
  - calls callAI() to rank top 3 with reasoning
  - returns same JSON shape as recommendLecturers
```

**Frontend — `src/components/dashboard/IncomingRequests.tsx`:**
- Add "Reassign" button next to Accept/Decline
- Clicking opens a modal/sheet with:
  - AI loading animation while fetching recommendations
  - 3 AI-recommended lecturer cards (name, reason, matching slot)
  - "Atau pilih dosen lain" dropdown (full list)
  - Optional "Alasan Reassign" text field
  - "Reassign" (primary) + "Batal" buttons

**Suggested commit:** `feat(lecturer): add AI-powered reassign consultation feature`

**If it breaks:** If `recommendReassignTargets` returns no results, check that the `consultations` table has the `reassignedFrom/To/Reason` fields from Task 2's schema migration. Also verify the lecturer being reassigned from is excluded from the candidate list.

---

### Task 10 — Official UNKLAB seed data
**Files:** `convex/seed.ts`, `convex/chat.ts`

Full rewrite of `convex/seed.ts` with:
- 24 lecturers (per the table in `CLAUDE.md`) — skip "Jordy Gapian" (no email)
- Correct Andria K. Wahyudi role to `lecturer` (source data incorrectly sets it to `student`)
- 25 students (per the table in `CLAUDE.md`)
- Call `clearLecturers` first before seeding new data

Also sync the lecturer list embedded in `convex/chat.ts:136-209` (the system prompt hardcoded section) to match the new seed data.

**User must run manually:**
```bash
npx convex run seed:clearLecturers
npx convex run seed:seedTestAccounts
```

**Suggested commit:** `feat(seed): replace dummy data with official UNKLAB lecturer and student data`

**If it breaks:** If `seedTestAccounts` fails partway through (e.g., duplicate email), run `clearLecturers` again and retry. All emails in the seed must be lowercase with no spaces — double-check before running.

---

## End-to-End Verification (after all 10 tasks)

Run these after the branch is complete and seed data is loaded.

1. `npm run build` — must pass with zero TypeScript errors
2. `npm run dev` + `npx convex dev` — both must start clean
3. Seed: `npx convex run seed:clearLecturers && npx convex run seed:seedTestAccounts`

**Smoke tests:**

| Flow | Login as | Steps | Pass when |
|---|---|---|---|
| Student booking | `s2222051001@student.unklab.ac.id` / `student123` | Book → fill topic → click "Cari Dosen dengan AI" → wait for loading overlay → pick lecturer → choose Online + platform → submit | Booking created; lecturer gets notification |
| Tatap muka location | same | Choose Tatap Muka → enter location detail | `locationDetail` saved to DB |
| Lecturer accept | `stenly.pungus@dosen.unklab.ac.id` / `dosen123` | Accept incoming request | Status changes; student notified |
| Reassign | same | Click Reassign → wait for AI loading → pick from recommendations → submit | Booking reassigned; both student and new lecturer notified |
| Profile tabs | any | Open profile → see Info Pribadi / Keamanan / Jadwal Tersedia tabs | All tabs render; Jadwal only for lecturers |
| Avatar upload | any | Click camera icon → upload a JPG → wait for spinner | Avatar updates; useStorageUrl resolves |
| Change password | any | Keamanan tab → change password → logout → login with new password | Login succeeds with new credential |
| AM/PM badge | any | Hover AM or PM badge in availability or booking time fields | Tooltip shows correct time range |
| AI provider swap | — | Set `AI_PROVIDER=mistral` in Convex Dashboard → repeat booking AI flow | Recommendations still return without code change |
