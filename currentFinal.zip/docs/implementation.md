# Implementation Plan — Ayo Konsultasi

> **Keep this file updated** after every feature is completed.
> This is the single source of truth for what's been built and what's next.

---

## Project Status: 🚧 In Progress

**Last updated:** 2026-05-03
**Current branch:** `cleanup/david-features`
**Next up:** See [docs/cleanup-plan.md](cleanup-plan.md) for the full task sequence and live status

> **Cleanup branch in progress.** The codebase absorbed a merge from a teammate and is being
> cleaned up before new feature branches begin. Tasks 0–10 are tracked in `docs/cleanup-plan.md`.
> After `cleanup/david-features` merges → `development`, the next branches are:
> - `feature/otp-password-reset`
> - `feature/auth-ui-animation`

---

## Features Roadmap

| # | Feature | Branch | Status | Notes |
|---|---------|--------|--------|-------|
| 0 | Auth page layout fix | `fix/auth-layout-centering` | ✅ Done | Desktop split + mobile no-scroll, panels corrected |
| 1 | Auth — Backend + DB | `feature/auth-backend` | ✅ Done | Convex Auth + Password + userProfiles schema + ProtectedRoute |
| 2 | Dashboard — Student | `feature/dashboard-student` |  ✅ Done | Home, stats, quick actions |
| 3 | Dashboard — Lecturer | `feature/dashboard-lecturer` |  ✅ Done | Incoming requests, schedule view |
| 4 | Lecturer Profile & Availability | `feature/lecturer-availability` | ⬜ Not started | Expertise tags, available slots schema |
| 5 | AI Recommendation Engine | `feature/ai-recommendation` | ⬜ Not started | Gemini matches student need → lecturer |
| 6 | Consultation Booking | `feature/consultation-booking` | ⬜ Not started | Calendar picker, free time input |
| 7 | Consultation Management | `feature/consultation-management` | ⬜ Not started | Accept/reject/cancel, status flow |
| 8 | Notification System | `feature/notifications` | ⬜ Not started | Bell icon (Lovable yellow style), real-time |
| 9 | Consultation History | `feature/consultation-history` | ⬜ Not started | Past sessions, filters |
| 10 | Profile Management | `feature/profile-management` |  ✅ Done | Edit profile (no delete account) |
| 11 | Polish + Testing | `feature/testing-and-polish` | ⬜ Not started | Unit tests, error states, UX |

**Legend:** ✅ Done | 🔄 In Progress | ⏳ Next | ⬜ Not started

---

## Feature Details

---

### FIX-0: Auth Page Layout Fix — Desktop Centering + Mobile Responsive
**Branch:** `fix/auth-layout-centering`

**Problem:**
1. Left section on login/register pages is stretched and left-aligned instead of compact and centered (desktop)
2. No mobile layout defined — auth pages break or require scrolling on small screens

**Solution — Desktop (`md:` and above):**
- Outer wrapper: `flex h-screen` → two 50% panels side by side
- Left panel wrapper: `hidden md:flex w-1/2 flex items-center justify-center` (brand/illustration)
- Left content block: `max-w-sm w-full` — compact, does NOT stretch to fill the panel
- Right panel: `flex w-full md:w-1/2 items-center justify-center` — form centered

**Solution — Mobile (below `md:`):**
- Left brand panel is hidden entirely (`hidden md:flex`)
- Right panel becomes full-screen: `w-full h-screen flex flex-col justify-center px-6`
- **Zero scrolling constraint:** the entire form (logo + fields + button + link) must be visible without scrolling
  - Use compact vertical spacing: `gap-3` or `gap-4` between form elements, `py-2` on inputs
  - If register form is taller, reduce spacing further or use `text-sm` on labels
  - Test at 375px viewport height (iPhone SE — worst case)
- Password show/hide toggle: minimum touch target `min-w-[44px] min-h-[44px]`

**Files to modify:** `src/pages/LoginPage.tsx`, `src/pages/RegisterPage.tsx` (and any shared auth layout component)

**Commit message when done:**
```
fix(auth): responsive auth layout — desktop centering + mobile no-scroll single column
```

**PR description:**
```
## Fix: Auth Page Layout — Desktop + Mobile

### Problems fixed
1. Left panel was stretched/left-aligned on desktop
2. No mobile layout — form required scrolling on small screens

### Solution
- Desktop: left panel content compact + centered using flex + max-w-sm
- Mobile: brand panel hidden, full-screen single-column form, zero scroll
- Password toggle meets 44×44px touch target requirement

### Testing checklist
- [ ] Login — left panel centered on desktop (1280px)
- [ ] Register — left panel centered on desktop (1280px)
- [ ] Login — fits without scroll on mobile 375×667px (iPhone SE)
- [ ] Register — fits without scroll on mobile 375×667px (iPhone SE)
- [ ] Password show/hide toggle tappable on mobile
- [ ] No horizontal overflow on any viewport
```

---

### FEATURE-1: Auth Backend Integration
**Branch:** `feature/auth-backend`

**What to build:**
- Convex Auth setup (using `@convex-dev/auth`)
- User schema in `convex/schema.ts`
- `convex/users.ts` — create user profile on first sign-in
- Connect Login/Register frontend to Convex Auth
- Protected routes (redirect to login if not authenticated)
- Role system: `student` | `lecturer`

**Convex Schema:**
```typescript
users: defineTable({
  name: v.string(),
  email: v.string(),
  role: v.union(v.literal("student"), v.literal("lecturer")),
  avatarUrl: v.optional(v.string()),
  major: v.optional(v.string()),       // for students
  expertise: v.optional(v.string()),   // for lecturers
  createdAt: v.number(),
})
.index("by_email", ["email"])
```

**Security notes:**
- Convex Auth hashes passwords internally — never call bcrypt manually or store plain text
- Seed/demo accounts use these default passwords (Convex Auth will hash them on creation):
  - Lecturer default password: `dosen123`
  - Student default password: `student67`
- Create a `convex/seed.ts` helper that inserts demo accounts (1 lecturer, 1 student) for testing — only run manually, never auto-run on deploy

**Pressman link:** Requirements R-01, R-02 (see user-stories.md)

**Commit message when done:**
```
feat(auth): integrate Convex Auth with login/register + user schema + seed accounts
```

**PR description:**
```
## Feature: Auth Backend Integration

### What's included
- Convex Auth setup and configuration
- User table schema with role-based fields
- Auto-create user profile on first sign-in
- Protected route wrapper component
- Role-based redirect (student → student dashboard, lecturer → lecturer dashboard)

### Architecture decisions
- Used Convex built-in auth for simplicity and tight DB integration
- Role stored in users table (not JWT claims) for flexibility

### Testing
- [ ] Register as student → redirected to student dashboard
- [ ] Register as lecturer → redirected to lecturer dashboard  
- [ ] Unauthenticated user → redirected to login
- [ ] Existing user login works
```

---

### FEATURE-2: Student Dashboard
**Branch:** `feature/dashboard-student`

**What to build:**
- Student dashboard page layout (Figma reference)
- Sidebar navigation
- Stats widgets (upcoming consultations, history count)
- Quick action buttons (Book consultation)
- Recent activity list (placeholder data until Feature 4)

**Commit message when done:**
```
feat(dashboard): add student dashboard with sidebar and stats widgets
```

---

### FEATURE-3: Lecturer Dashboard
**Branch:** `feature/dashboard-lecturer`

**What to build:**
- Lecturer dashboard layout
- Incoming consultation requests list
- Weekly schedule overview
- Quick stats (pending, accepted, completed)

**Commit message when done:**
```
feat(dashboard): add lecturer dashboard with request management view
```

---

### FEATURE-6: Consultation Booking
**Branch:** `feature/consultation-booking`

**What to build:**
- Browse/search lecturers page
- Booking form:
  - Select lecturer
  - **Calendar date picker** (not text input — use a proper calendar UI)
  - **Free-form time input** (hour + minute — user sets any time, not preset slots)
  - Topic/notes field
  - Subject/course field
- `convex/consultations.ts` — createConsultation mutation
- Validation (can't book in the past, etc.)

**Convex Schema:**
```typescript
consultations: defineTable({
  studentId: v.id("users"),
  lecturerId: v.id("users"),
  date: v.string(),                    // ISO date string
  time: v.string(),                    // "HH:mm" format
  topic: v.string(),
  notes: v.optional(v.string()),
  status: v.union(
    v.literal("pending"),
    v.literal("accepted"),
    v.literal("rejected"),
    v.literal("completed"),
    v.literal("cancelled")
  ),
  createdAt: v.number(),
  updatedAt: v.number(),
})
.index("by_student", ["studentId"])
.index("by_lecturer", ["lecturerId"])
.index("by_status", ["status"])
```

**Commit message when done:**
```
feat(booking): add consultation booking with calendar and free-form time picker
```

---

### FEATURE-7: Consultation Management
**Branch:** `feature/consultation-management`

**What to build:**
- Lecturer: accept / reject incoming requests
- Student: cancel pending request
- Status change triggers notification (sets up for Feature 6)
- Consultation detail page

**Commit message when done:**
```
feat(consultation): add accept/reject/cancel flow with status management
```

---

### FEATURE-8: Notification System
**Branch:** `feature/notifications`

**What to build:**
- Notification bell in navbar
- **Yellow dot indicator** (Lovable design) for unread count
- Dropdown list of notifications
- Mark as read
- Real-time updates via Convex reactive query

**Convex Schema:**
```typescript
notifications: defineTable({
  userId: v.id("users"),
  type: v.string(),                    // "booking_accepted" | "booking_rejected" | "new_booking" etc.
  message: v.string(),
  relatedId: v.optional(v.id("consultations")),
  isRead: v.boolean(),
  createdAt: v.number(),
})
.index("by_user", ["userId"])
.index("by_user_unread", ["userId", "isRead"])
```

**Commit message when done:**
```
feat(notifications): add real-time notification bell with yellow unread indicator
```

---

### FEATURE-9: Consultation History
**Branch:** `feature/consultation-history`

**What to build:**
- History list page (completed/cancelled consultations)
- Filter by date, lecturer, status
- Detail view for past consultations

**Commit message when done:**
```
feat(history): add consultation history page with filters
```

---

### FEATURE-4: Lecturer Availability Setup
**Branch:** `feature/lecturer-availability`

**What to build:**
- Lecturer can set expertise/subject tags (e.g. "Machine Learning", "Thesis Guidance")
- Lecturer sets weekly availability (which days + time ranges)
- This data feeds the AI recommendation engine in Feature 5

**Convex Schema additions to users table:**
```typescript
expertise: v.optional(v.array(v.string())),
availability: v.optional(v.array(v.object({
  day: v.string(),         // "monday" | "tuesday" | ...
  startTime: v.string(),   // "09:00"
  endTime: v.string(),     // "17:00"
}))),
```

**Commit message when done:**
```
feat(lecturer): add expertise tags and weekly availability setup
```

**PR description:**
```
## Feature: Lecturer Availability Setup

### What's included
- Lecturer profile: add/remove expertise tags
- Weekly availability editor (day + time range blocks)
- Convex schema updated with expertise[] and availability[] fields

### Pressman traceability
- Implements user story: US-11, US-16

### Testing checklist
- [ ] Lecturer can add/remove multiple expertise tags
- [ ] Lecturer can set different availability per day
- [ ] Data persists correctly in Convex
```

---

### FEATURE-5: AI Lecturer Recommendation Engine (Gemini)
**Branch:** `feature/ai-recommendation`

**What to build:**
- "Find a Lecturer" flow: student fills a consultation need form
  - Topic/subject (free text)
  - Brief description of their problem
  - Preferred date range
- Convex Action fetches all lecturers + expertise + availability from DB
- Send structured prompt to Gemini → parse ranked recommendations as JSON
- Display top 3 recommended lecturers with match score + reason
- "Book this lecturer" CTA directly from recommendation card

**Flow:**
```
Student fills need form
        ↓
Convex Action: ai.recommendLecturers()
        ↓
Fetch all lecturers + expertise + availability
        ↓
Build structured prompt → call Gemini (server-side, API key safe)
        ↓
Parse JSON response → return ranked list
        ↓
UI shows top 3 with matchReason + suggestedSlots
```

**Gemini prompt strategy (returns strict JSON):**
```
System: You are an academic consultation assistant. Given a student's consultation
need and a list of lecturers with their expertise, return the top 3 best-matched
lecturers. Respond ONLY in valid JSON — no markdown, no explanation outside JSON.

Return format:
[{ "lecturerId", "lecturerName", "matchScore": 0-100,
   "matchReason": "...", "suggestedSlots": ["Mon 10:00", ...] }]
```

**Model config (no code change needed to switch):**
```typescript
const model = process.env.GEMINI_MODEL ?? "gemini-1.5-flash";
// Dev:  GEMINI_MODEL=gemini-1.5-flash  (fast, cheap)
// Demo: GEMINI_MODEL=gemini-1.5-pro    (higher quality)
```

**Commit message when done:**
```
feat(ai): add Gemini-powered lecturer recommendation engine via Convex Action
```

**PR description:**
```
## Feature: AI Lecturer Recommendation Engine

### What's included
- "Find a Lecturer" form: topic, description, preferred dates
- Convex Action `recommendLecturers` — Gemini called server-side only
- Structured JSON prompt with error handling for malformed responses
- Recommendation results UI: top 3 cards with match score + reason
- Direct "Book this lecturer" CTA from each recommendation card
- Model switching via GEMINI_MODEL env var only — zero code change for demo

### Architecture decisions
- Gemini called via Convex Action — API key NEVER exposed to browser
- Response parsed as strict JSON; fallback UI shown if AI fails

### Pressman traceability
- Implements user story: US-04, US-05

### Testing checklist
- [ ] Recommendations return in < 5 seconds
- [ ] Correct lecturers matched to topic
- [ ] Fallback UI shown if Gemini fails
- [ ] Booking CTA works from recommendation card
```

---

### FEATURE-10: Profile Management
**Branch:** `feature/profile-management`

**What to build:**
- Edit profile page
- Update name, avatar, major (student) / expertise (lecturer)
- Change password
- **DO NOT implement:** Delete account option

**Commit message when done:**
```
feat(profile): add profile management page (edit info + change password)
```

---

### FEATURE-11: Testing & Polish
**Branch:** `feature/testing-and-polish`

**What to build:**
- Unit tests for Convex functions (use Convex testing utilities)
- Loading states on all async operations
- Empty states (no consultations yet, etc.)
- Error boundaries
- Form validation polish
- Responsive layout check

**Commit message when done:**
```
feat(quality): add unit tests, loading states, and UX polish
```

---

## Architecture Decisions Log

| Decision | Choice | Reason |
|----------|--------|--------|
| Auth provider | Convex Auth | Tight integration with Convex DB, no extra service |
| AI calls | Via Convex Actions (server-side) | API key never exposed to browser |
| State management | Convex reactive queries | Built-in real-time, no Redux needed |
| UI components | shadcn/ui + Tailwind | Industry standard, matches Figma color system well |
| Date picker | Calendar component (shadcn Popover + Calendar) | Figma specifies calendar UI |
| Time picker | Free-form HH:mm input | User requirement: any time, not preset slots |
